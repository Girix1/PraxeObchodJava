package jh;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        int cena = 0;
        int i = 0;
    while (i<10){


        System.out.println("Vyberte kategorii do které chcete vstoupit:");
        System.out.println("jídlo");
        System.out.println("pití");
        System.out.println("ostatní");
        System.out.println("");
        System.out.println("PLATBA");

        String kategorie = sc.nextLine();
        switch (kategorie) {
            case "jídlo" -> {
                System.out.println("párek v rohlíku: 35,-");
                System.out.println("svíčková: 150,-");
                System.out.println("trdelník: 100,-");
                String zbozi = sc.nextLine();
                switch (zbozi){
                    case "párek v rohlíku" ->{
                         cena += 35;
                    }
                    case "svíčková" ->{
                         cena += 150;
                    }
                    case "trdelník" ->{
                         cena += 100;
                    }
                }

            }
            case "pití" -> {
                System.out.println("jablečný džus: 40,-");
                System.out.println("pilsner urqell: 50,-");
                System.out.println("dobrá voda: 15,-");
                String zbozi = sc.nextLine();
                switch (zbozi){
                    case "jablečný džus" ->{
                         cena += 40;
                    }
                    case "pilsner urqell" ->{
                         cena += 50;
                    }
                    case "dobrá voda" ->{
                         cena += 15;
                    }
                }

            }
            case "ostatní" -> {
                System.out.println("provaz: 200,-");
                System.out.println("kondomy: 69,-");
                System.out.println("tajná myškavěc: 420,-");
                String zbozi = sc.nextLine();
                switch (zbozi){
                    case "provaz" ->{
                        cena += 200;
                    }
                    case "kondomy" ->{
                        cena += 69;
                    }
                    case "tajná myškavěc" ->{
                        cena += 420;
                    }
                }
            }
            case "PLATBA" -> {
                System.out.print("Máte nákup v hodnotě ");
                System.out.print(cena);
                System.out.println(" Kč");
                System.out.println("Pro potvrzeni platby napište: POTVRZUJI PLATBU");
                String potvrzeni = sc.nextLine();

                if (potvrzeni.equals("POTVRZUJI PLATBU") ){
                    System.out.println("Děkujeme za váš nákup");
                    i += 69;
                }else {
                    System.out.println("CHYBA");
                }

            }
            default -> {
            System.out.println("ERROR 404");
            }
        }
    }


    }
}
